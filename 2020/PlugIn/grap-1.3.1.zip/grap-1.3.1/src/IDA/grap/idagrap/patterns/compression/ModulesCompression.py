#!/usr/bin/env python

COMPRESSION = {
}
