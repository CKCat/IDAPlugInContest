#!/usr/bin/env python

# Tuple of block ciphers
CRYPTO_BLOCK = (
)
