#!/usr/bin/env python

class NodeException(Exception):
    pass

class CodeException(NodeException):
    pass
