#!/usr/bin/env python

from .misc.ModulesTestMisc import get_test_misc

TEST = {
    "Misc": get_test_misc(),
}

