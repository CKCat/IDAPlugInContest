#!/usr/bin/env python

# Tuple of hashes
CRYPTO_HASH = (
)
