#!/usr/bin/env python

# Tuple of modes of operation
CRYPTO_MODE = (
)
