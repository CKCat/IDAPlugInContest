#ifndef UTILS_GTSI_H
#define UTILS_GTSI_H

#include <string>
#include "my_alloc.hpp"

using namespace std;

string b2s(bool b);
string h2s(uint64_t a);

#endif