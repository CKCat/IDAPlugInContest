# grap syntax highlighting
## Vim syntax file
Here is a vim syntax highlighting file: [../src/syntax/vim/grap.vim](../src/syntax/vim/grap.vim)

It can be used by **either** :
*  Copying it to ~/.vim/ftdetect/
*  Loading it from ~/.vimrc with a line such as:
   ```
   source ~/grap/src/syntax/vim/grap.vim
   ```
