Bf_proc.py adds brainfuck language to the hex-rays decompiler.

1) open any bf file as a binary file (metapc processor, 32-bit code)
2) use File / Load script file menu to load the bf_proc.py file.
3) enjoy your hex-rays brainfuck decompiler


Disclaimer:
 The decompiled code is not very readable and IDA sometimes
crashes. But overall it nicely demonstrates that hex-rays are
capable of awesome things.

-- 
Milan Bohacek
