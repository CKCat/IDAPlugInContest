
# Research Tools
A collection of tools we developed to accelerate our security research projects. Additional content will be posted on our blog https://blog.claroty.com.

## Tools
| Tools | Description |
| :---: |-------------|
|IDA| A collection of ida utilities including scripts and plugins we developed over the years.|