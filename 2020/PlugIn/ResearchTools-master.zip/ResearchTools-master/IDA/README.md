
# IDA Utilities
IDA utilities we developed to accelerate our security research projects.

## Tools
| Tool | Description |
| :---: |-------------|
|Renamer| A plugin which helps in the process of naming functions based on their strings.|