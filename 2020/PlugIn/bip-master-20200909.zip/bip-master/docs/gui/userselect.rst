.. _gui-user-select:

User selections
###############

.. module:: bip.gui

The :class:`BipUserSelect` class is in charge of regrouping several methods
allowing to interact with the user selections.

As of now this class contains only static methods.

BipUserSelect API
=================

.. autoclass:: BipUserSelect
    :members:
    :member-order: bysource
    :special-members:
    :private-members:



