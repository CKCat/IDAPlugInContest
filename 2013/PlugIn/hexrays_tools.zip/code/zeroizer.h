#pragma once

extern void convert_zeroes(cfunc_t *cfunc);