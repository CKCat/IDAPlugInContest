#pragma once
extern bool idaapi show_classes_view(void *ud);