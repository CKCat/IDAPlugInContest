#pragma once
extern bool idaapi show_new_struc_view(field_info_t * fi);