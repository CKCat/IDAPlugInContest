#pragma once

extern void idaapi run_graph(int /*arg*/);