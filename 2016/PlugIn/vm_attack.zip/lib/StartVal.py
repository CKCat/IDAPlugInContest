#!/usr/bin/env python

ASSEMBLER_64 = 64
ASSEMBLER_32 = 32

dissassm_type = 0
