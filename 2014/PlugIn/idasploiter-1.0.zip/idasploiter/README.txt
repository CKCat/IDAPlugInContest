Welcome to IDA Sploiter, an exploit development and vulnerability research
plugin for Hex-Ray's IDA Pro disassembler.

To install IDA Sploiter simply copy 'idasploiter.py' to IDA's plugins folder.
The plugin will be automatically loaded the next time you start IDA Pro.

You can find the latest IDA Sploiter version and documentation here: 
    http://thesprawl.org/projects/ida-sploiter/

Happy sploiting!
  -Peter Kacherginsky <iphelix@thesprawl.org>