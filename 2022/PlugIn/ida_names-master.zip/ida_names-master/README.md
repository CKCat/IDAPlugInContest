# IDA-names

*IDA-names* automatically renames pseudocode windows with the current function name. It can also rename *ANY* window with `SHIFT-T` hotkey.

## Install

Just drop `ida_names.py` in plugins folder. Feel free to change default hotkey as well!

## Showcase

![1](./media/showcase.gif)