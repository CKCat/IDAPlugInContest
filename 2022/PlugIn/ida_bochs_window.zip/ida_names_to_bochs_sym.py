# by Dreg

filename = ida_kernwin.ask_file(True, "*.txt", "Select file to save symbols")

str = ""
for addr, name in Names():
    str += hex(addr) + " " + name + "\n"

with open(filename, "w+") as file:
    file.write(str)
    
print(str[:100] + "....")

print("done symbols saved -> ", filename)

# just in bochs: ldsym "C:\\Users\\Dreg\\bochs\\sym.txt"