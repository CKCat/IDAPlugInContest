# Roadmap

A lot of things are missing from `Quokka`.

In no particular order :

* export and use types information
* expose operands data in a comprehensive way
* performances improvements of the references
 