class callstack_helpers {
public:
	callstack_helpers() ;
	~callstack_helpers();
private:
	void setup_callstack_type(void);
	void remove_callstack_type(void);
};