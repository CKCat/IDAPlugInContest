void setup_openshlib(void);
error_t load_shared_library(const char *);
