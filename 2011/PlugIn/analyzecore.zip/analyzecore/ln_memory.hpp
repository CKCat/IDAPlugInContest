class m_group_helpers {
public:
	m_group_helpers() ;
	~m_group_helpers();
private:
	void setup_m_entry_type(void);
	void remove_m_entry_type(void);
};
error_t analyze_m_groups(void);