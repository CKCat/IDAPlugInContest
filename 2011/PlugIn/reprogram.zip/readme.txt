REProgram allows you to make almost-arbitrary changes to an executable
when run under the debugger.

To use it, select the region of code you wish to replace, and run
REProgram from the Plugins menu or press Alt+F2. In the prompt that pops
up, enter the (possibly empty) code that you wish to run instead of the
selected code. To return the region to normal, place your cursor anywhere
within the reprogrammed region and run the plugin again.

A list of all reprogrammed regions is available under the View menu.

REProgram has two modes of working. If the assembly you type in is not
larger than the original selection, it will behave essentially the same as
if you patched the original executable. When you run the program in the
debugger, REProgram will replace the code in the selection with the
provided code, and fill in any remaining space with NOPs. As a bonus,
using REProgram to modify data segments also works in this case.

If the assembly you type in is larger than the original selection, when
control reaches a reprogrammed region, REProgram will place as many
instructions in the region as it can, and run control through that space
over and over until all the desired instructions have been executed
control passes outside of the region. In this case, jumps to the inside of
the reprogrammed region are not guaranteed to work, although jumps from
the region to the outside are. Note that, as REProgram uses breakpoints to
implement this behavior, focus will return to IDA every time a region
reprogrammed in this manner is hit; minimizing IDA is recommended.

Limitations:

Only x86 is supported. REProgram uses IDA's onboard assembler, and suffers
from all its shortcomings. One workaround is to use the db directive to
specify an instruction by what it assembles to.

REProgram cannot handle the case where there is an instruction larger than
the reprogrammed region it is meant to fit in; this can typically be
overcome just be widening the region to include adjacent instructions and
adding them to the reprogramming code.