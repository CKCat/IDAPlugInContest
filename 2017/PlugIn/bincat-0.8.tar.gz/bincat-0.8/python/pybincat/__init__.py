
class PyBinCATException(Exception):
    pass
