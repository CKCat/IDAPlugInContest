#!/bin/sh
export FLASK_DEBUG=1
python2 wsgi.py
