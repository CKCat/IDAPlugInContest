# Experimental opaque predicate detection for IDA Pro

Drop (**D**rop **R**emoves **O**paque **P**redicates) is an IDA Pro plugin capable of detecting several types of opaque predicates in obfuscated binaries by making use of the symbolic-execution engine *angr* and its components.
Specifically, Drop can detect, highlight and (primitively) remove the following types of opaque predicates:

- invariant opaque predicates (i.e. "normal" opaque predicates without context)
- contextual opaque predicates (i.e. opaque predicates that depend on one or more invariants at the predicate location)

In general, the plugin is built to be as interactive as possible, allowing the analyst to specify additional context through function hooking, symbolic global variables and additional (in-)equality constraints.

## Disclaimers

- This code was written by me (Thomas Rinsma) during an internship. It is not a Riscure product and Riscure does not support or maintain this code.
- This is experimental code, intended as an experiment to see what can be accomplished by combining `angr` and IDA Pro for this purpose.
    - Because of certain heuristics, the plugin will in various scenarios result in false positives, false negatives, or both.
    - In certain (often complex) functions, SMT constraints will become very large, and solving time might become unreasonably large.
  	  Drop provides a button to kill the current analysis, but because of Z3's architecture, this can occasionally kill IDA itself as well.
      It is therefore recommended you save your database before performing any heavy analysis.

## Third-party dependencies

Because of the instable nature of the APIs provided by angr and its components, Drop requires a very specific version of each to be installed.
In order to make installation easier, some of these have been provided as Python `.egg` files in the `dependencies` folder.
See the *Installation* section below for instructions on how to install these dependencies.

## Installation

This assumes a 64-bit Windows 7 installation with IDA 6.95.
Currently, IDA 7.0 and 64-bit Python are not supported. This might change in the future.

It is assumed that (32-bit) Python 2.7, `pip` and `easy_install` are installed, as they come with IDA 6.95.

1. Make sure the 32-bit Python 2.7 executable directories are in your PATH:
		`;C:\Python27;C:\Python27\Scripts`

2. Run the following commands:
		`cd path_to_drop/dependencies`
		`pip install -r requirements.txt`
		`easy_install -Z archinfo-6.7.1.13-py2.7.egg pyvex-6.7.1.31-py2.7.egg cle-6.7.1.31-py2.7.egg simuvex-6.7.1.31-py2.7.egg capstone-3.0.4-py2.7.egg angr-6.7.1.31-py2.7.egg`
	
3. Copy `drop/` and `drop.py` to `plugins/` in your IDA installation folder.

4. Done!

## Basic usage
See `how_to_use.txt`
