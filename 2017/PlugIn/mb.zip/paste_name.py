""" Sets the name of an item in decompiler to a name from the clipboard

Author: Milan Bohacek, 2017
License: GPL

"""

import idaapi
import idc

#pip install -U pyperclip
from pyperclip import paste

def rename(vu, new_name):

        if vu.item.citype == idaapi.VDI_FUNC:
                #print "renaming %x to %s"%( vu.cfunc.entry_ea, new_name );
                return idaapi.do_name_anyway( vu.cfunc.entry_ea, str(new_name) );
        lvar = vu.item.get_lvar( );
        if lvar:
                #print "renaming %s to %s"%( lvar.name, new_name )
                return rename_lvar( vu, lvar, new_name )
        e = vu.item.e;
        if ( e.op == idaapi.cot_obj ):
                #print "renaming %x to %s"%( e.obj_ea, new_name );
                return idaapi.do_name_anyway( e.obj_ea, str(new_name) );
        sptr = 0;
        #suggested by Arnaud on 15. 12. 2015 10:37
        mem = vu.item.get_memptr()
        sptr = idaapi.get_member_struc(idaapi.get_member_fullname(mem.id)) 
        #mem = vu.item.get_memptr( &sptr );
        if ( mem ):
                #print "renaming %d to %s"%( mem.id, new_name )
                return idaapi.set_member_name( sptr, mem.soff, new_name );
        return 0;


def rename_lvar( vu, lvar, new_name ):
        if ( vu.rename_lvar( lvar, new_name, True ) ):
		return True;

        for i in range(20):
		name = "%s_%d"%( new_name, i)
                if ( vu.rename_lvar( lvar, name, True ) ):
			return True
	return False;



class paste_action_handler_t(idaapi.action_handler_t):
    def __init__(self):
        idaapi.action_handler_t.__init__(self)

    def activate(self, ctx):
        vu = idaapi.get_widget_vdui(ctx.widget)
        vu.get_current_item(idaapi.USE_KEYBOARD)
        #global last_vu
        #last_vu = vu
        #IDA accepts only 'char *' -> must use str()
        new_name = str(paste())
        if not new_name:
            return 0
        rename(vu, new_name)
        return 1

    def update(self, ctx):
        return idaapi.AST_ENABLE_FOR_WIDGET if ctx.widget_type == idaapi.BWN_PSEUDOCODE else idaapi.AST_DISABLE_FOR_WIDGET



class PastePlugin(idaapi.plugin_t):
    flags = idaapi.PLUGIN_HIDE
    comment = "provides a paste name action for hex-rays"
    help = ""
    wanted_name = "hx_paste"
    actname = "mb:paste"
    wanted_hotkey = ""


    def init(self):
        addon = idaapi.addon_info_t();
        addon.id = "milan.bohacek.paste_name";
        addon.name = "name paster";
        addon.producer = "Milan Bohacek";
        addon.url = "milan.bohacek+pastename@gmail.com";
        addon.version = "7.00";
        idaapi.register_addon( addon );
        api_register_actions()
        if idaapi.init_hexrays_plugin():
            idaapi.register_action( idaapi.action_desc_t( self.actname, "paste name", paste_action_handler_t(), "Ctrl+V"))
        else:
            print 'hx:paste: hexrays is not available.'
            return idaapi.PLUGIN_SKIP
        return idaapi.PLUGIN_KEEP

    def term(self):
        idaapi.unregister_action(self.actname)
        pass

    def run(self, arg):
        pass


def PLUGIN_ENTRY():
    return PastePlugin()



