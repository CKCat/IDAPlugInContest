import idaapi
import idc

# milan.bohacek@gmail.com
# idea stolen from fireye, https://www.fireeye.com/blog/threat-research/2013/06/applying-function-types-structure-fields-ida.html
# but instead of letting the user choose which type to apply, I'm doing it automatically
# works probably only in IDA 7 though
# license: GPL
# TODO: do the same for hexrays variables


def type_for_name(s):
  named_type = idaapi.get_named_type(None, s, 0)
  if named_type is None:
    return None
  t = idaapi.tinfo_t()
  t.deserialize(None, named_type[1], named_type[2])
  t = idaapi.make_pointer(t)
  return t


class renaming_hook(idaapi.IDB_Hooks):
    def __init__(self):
        idaapi.IDB_Hooks.__init__(self)

    def struc_member_renamed(self, sptr, mptr):
        """
        struc_member_renamed(self, sptr, mptr) -> int
        """
        name = idaapi.get_member_name(mptr.id)
        tif = type_for_name(name)
        if not tif:
            return 0

        flags = idaapi.SET_MEMTI_COMPATIBLE | idaapi.SET_MEMTI_USERTI
 
        code = idaapi.set_member_tinfo(sptr, mptr, 0, tif, flags)
        return 0

class auto_struc_member_type_t(idaapi.plugin_t):
	flags = idaapi.PLUGIN_PROC | idaapi.PLUGIN_HIDE
	comment = "automatically sets member type"
	wanted_hotkey = ""
	help = "Runs transparently"
	wanted_name = "auto_struc_member_type"
	hook = None

	def init(self):
		self.hook = None
                addon = idaapi.addon_info_t();
                addon.id = "milan.bohacek.member_typer";
                addon.name = "member typer";
                addon.producer = "Milan Bohacek";
                addon.url = "milan.bohacek+membertyper@gmail.com";
                addon.version = "7.00";
                idaapi.register_addon( addon );
		self.hook = renaming_hook()
		self.hook.hook()
		return idaapi.PLUGIN_KEEP

	def run(self, arg):
		pass

	def term(self):
		if self.hook:
			self.hook.unhook()

def PLUGIN_ENTRY():
	return auto_struc_member_type_t()
