/*
*  Interactive disassembler (IDA).
*  Adobe Flash ActionScript2 processor module
*  Marian RADU <marianra@microsoft.com>
*/

#ifndef __REGISTERS_HPP
#define __REGISTERS_HPP

#include "../idaidp.hpp"

#endif