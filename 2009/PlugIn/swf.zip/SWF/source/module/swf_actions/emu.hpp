/*
*  Interactive disassembler (IDA).
*  Adobe Flash ActionScript2 processor module
*  Marian RADU <marianra@microsoft.com>
*/

#ifndef __EMU_HPP
#define __EMU_HPP

int __stdcall emu();

#endif
