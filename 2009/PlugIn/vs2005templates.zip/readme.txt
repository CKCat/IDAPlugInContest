
Visual Studio 2005 Templates for Plugins and Loaders




:: Overview

This is a template for easy creation of IDA Plugins and Loaders using
MS Visual Studio 2005 or later (ie VS2008 or VS2010)

This helps by setting all required settings, paths and preprocessor values
required to create both 32bit and 64bit modules from the same sourcecode.
This will save work and time even for those with experience writing plugins,
but it is of most use for those who are new to it and don't know where to start.




:: Install

Copy these into your IDA sdk directories to "install" them.



:: Usage

Open the solution file in Visual Studio to use the template. You should be
able to build a complete working plugin or loader straight away. You can then
get straight into developiong your plugins without worrying about the setup, just
make a copy of the directory and start editing the source code.



