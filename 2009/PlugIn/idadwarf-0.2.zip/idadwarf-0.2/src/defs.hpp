#ifndef IDADWARF_DEFS_HPP
#define IDADWARF_DEFS_HPP

#define PLUGIN_VERSION "0.2"

#define PLUGIN_NAME "IDADWARF ELF v" PLUGIN_VERSION

#define PLUGIN_HOTKEY "ALT-F9"

// only to overcome a namespace problem
// I swear I don't use dangerous functions
#define USE_DANGEROUS_FUNCTIONS

#endif // IDADWARF_DEFS_HPP
