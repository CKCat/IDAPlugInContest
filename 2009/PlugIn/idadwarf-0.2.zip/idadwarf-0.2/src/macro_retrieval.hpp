#ifndef IDADWARF_MACRO_RETRIEVAL_HPP
#define IDADWARF_MACRO_RETRIEVAL_HPP

// additional libs headers
#include <dwarf.h>
#include <libdwarf.h>

void retrieve_macros(Dwarf_Debug dbg);

#endif // IDADWARF_MACRO_RETRIEVAL_HPP
