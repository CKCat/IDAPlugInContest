IDAJava Install/Test
====================

0. Extract files to a directory of your choosing

1. Copy IDAJava.plw to your IDA plugins-directory

2. Run CreatePluginSettings.cmd to create PluginSettings.reg

3. Import PluginSettings.reg into registry

4. Open IDA and load a database

5. Run RunSample.cmd, enjoy!

