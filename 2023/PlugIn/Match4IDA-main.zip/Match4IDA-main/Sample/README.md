Please ask [@vxunderground](https://twitter.com/vxunderground) for the password!

Rules come from the YARA [signature base](https://github.com/Neo23x0/signature-base/blob/master/yara/apt_barracuda_esg_unc4841_jun23.yar).
