# -*- encoding: utf8 -*-
#
# This module allows an IPython to be embeded inside IDA.
#
# Copyright (c) 2015-2018 ESET
# Author: Marc-Etienne M.Léveillé <leveille@eset.com>
# See LICENSE file for redistribution.
