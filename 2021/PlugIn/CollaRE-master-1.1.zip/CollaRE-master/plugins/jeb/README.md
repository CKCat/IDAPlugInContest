# CollaRE JEB Plugin

## Installation

Load the scripts for import and export operations into the JEB via the scripting menu.

## Usage

Use export and import scripts from the script menu to migrate the data between different tools.


