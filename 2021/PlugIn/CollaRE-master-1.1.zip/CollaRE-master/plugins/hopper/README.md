# CollaRE Hopper Plugin

## Installation

Place both Import and Export scripts into the folder with Hopper scripts.

## Usage

Just run the script from the UI of Hopper. Make sure to always do Import before you export something to avoid data loss.


