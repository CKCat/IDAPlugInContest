# CollaRE (v1.0)
Author: **Martin Petran**

_This plugin allows synchronization of data between different databases in CollaRE project._

## Description:
This plugin allows synchronization of data between different databases in CollaRE project. See [CollaRE](https://github.com/Martyx00/CollaRE) for more information.

## Minimum Version

This plugin requires the following minimum version of Binary Ninja:

 * 2263


## Required Dependencies

The following dependencies are required for this plugin:

 * other - This plugin is designed to work with [CollaRE](https://github.com/Martyx00/CollaRE).


## License

This plugin is released under a Apache-2.0 license.

## Metadata Version

2
