# CollaRE IDA Plugin

## Installation

Place the file `CollaRE.py` into the plugin folder valid for your system.

## Usage

Options to `Import` and `Export` data will be added to the `File` menu. Note that the main purpose of this plugin is to migrate the data from one tool to another rather than a real-time collaboration on a single project. Also, be warned that doing import action will make all comments standard non-repeatable (sorry for that).


