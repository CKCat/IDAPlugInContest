#!/bin/sh
g++ unit-test-binary.cpp -g -c -m32 -O0
