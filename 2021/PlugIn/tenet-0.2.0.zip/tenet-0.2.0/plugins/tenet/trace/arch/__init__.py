from .x86 import ArchX86
from .amd64 import ArchAMD64