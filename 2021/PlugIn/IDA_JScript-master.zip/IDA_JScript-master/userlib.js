
//parlor trick to break up intellisense list into smaller segments..
var app = ida
var fso = ida 

function h(x){ return ida.intToHex(x);};
function t(x){ ida.t(x);};
function d(x){ list1.additem(x);};
function alert(x){ ida.alert(x);};
