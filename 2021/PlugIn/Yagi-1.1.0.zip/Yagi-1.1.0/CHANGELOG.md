# 1.1.0
* Add support for Atmel processor (#4)
* Change shortcut for decompilation now is :warning: **F3** :warning: (#5)
* Add clear shortcut to clear type definition for local var
* Change paradigm for findings symbols

# 1.0.1
* Bug fix in type caching