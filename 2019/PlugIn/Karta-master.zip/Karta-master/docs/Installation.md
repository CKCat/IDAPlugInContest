Installation
============
Prerequisites
----------------
**Karta** makes extensive use of 2 python packages:
* [elementals](https://github.com/eyalitki/elementals)
* [sark](https://github.com/tmr232/Sark)

Using the ```setup.py``` script, one can install all of these prerequisites, and be ready to go:
```./setup.py install```

Installing the Plugin
------------------------
Nothing should be done :)
There is no need to copy the directory to some IDA plugin folder. Instead, once your binary is loaded to IDA, simply start the desired plugin by loading it using the ```File->Script File...``` menu. That's it.