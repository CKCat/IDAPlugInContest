def idadir(suffix):
    return suffix