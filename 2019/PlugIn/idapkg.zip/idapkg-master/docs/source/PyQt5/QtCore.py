class QObject(object):
	pass

class QCoreApplication(object):
	pass

class QEvent(object):
	pass

pyqtSignal = lambda: True