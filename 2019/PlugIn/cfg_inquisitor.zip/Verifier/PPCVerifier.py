import idaapi
import idc
from ArchVerifier import ArchVerifier

class PPCVerifier(ArchVerifier):

    def __init__(self, arch):

        self.arch = arch
   
    def is_ra_saved(self, bb):
        """
        In the basic block, checks whether the semantic
        'sw $ra' exists in any instruction 
        """
        startea = bb.startEA
        endea = bb.endEA
        currea = startea
        while currea < endea:
            if idc.GetMnem(currea).lower() == 'sw' and \
                idc.GetOperandValue(currea, 0) == RA_VALUE and \
                idc.GetOpType(currea, 0) == idaapi.o_reg:
                return True
            currea = idc.NextHead(currea)
        return False

    def is_ra_restored(self, bb):
        """
        checks whether the return address is restored. and jumped back to 
        """
        startea = bb.startEA
        endea = bb.endEA
        currea = startea
        is_ra_retrieved = False
        is_ra_jumped = False
        
        while currea < endea:
            if is_ra_retrieved:
                if idc.GetMnem(currea).lower() == 'jr' and \
                    idc.GetOperandValue(currea, 0) == RA_VALUE:
                    is_ra_jumped = True
                    break
            elif idc.GetMnem(currea).lower() == 'lw' and \
                idc.GetOperandValue(currea, 0) == RA_VALUE and \
                idc.GetOpType(currea, 0) == idaapi.o_reg:
                is_ra_retrieved = True
            
            currea = idc.NextHead(currea)
        return (is_ra_retrieved and is_ra_jumped)


    def is_sp_increased(self, bb):
        """
        Checks whether stack pointer is increased
        """
        startea = bb.startEA
        endea = bb.endEA
        currea = startea
        total_change = 0 
        while currea < endea:
            if idc.GetMnem(currea).lower() == 'addiu' and \
                    idc.GetOperandValue(currea, 0) == SP_VALUE and \
                    idc.GetOperandValue(currea, 1) > 0:
                total_change += idc.GetOperandValue(currea, 1)
            currea = idc.NextHead(currea)
        return total_change

    def is_sp_decreased(self, bb):
        """
        Checks whether stack pointer is decreased
        """
        startea = bb.startEA
        endea = bb.endEA
        currea = startea
        total_change = 0 
        while currea < endea:
            if idc.GetMnem(currea).lower() == 'addiu' and \
                    idc.GetOperandValue(currea, 0) == SP_VALUE and \
                    idc.GetOperandValue(currea, 1) < 0:
                total_change += idc.GetOperandValue(curr, 1)
            currea = idc.NextHead(currea)
        return total_change
 

