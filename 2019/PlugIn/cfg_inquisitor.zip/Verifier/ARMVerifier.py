import idaapi
import idc
from ArchVerifier import ArchVerifier

SP_VALUE = 13
LR_VALUE = 14
PC_VALUE = 15
STM_OPCODE = 4

class ARMVerifier(ArchVerifier):

    def __init__(self, arch):

        self.arch = arch

    def _get_num_regs_from_reg_list(self, inst):
        """
        Count the number of register from a register list. 
        If the opcode is STM(store multiple), the last 16 bits of the instruction indicates
        which registers are going to be stored. e.g. a 1 in bit 0 field will cause
        r0 to be transferred so on and so forth
        """
        inst_bc = idc.Dword(inst)
        opcode = (inst_bc >> 25) % 8
        if opcode == STM_OPCODE:
            # Storing multiple registers onto the stack
            reg_list_bitlist = inst_bc % 0x10000
            return reg_list_bitlist
        else:
            # The push only stores a single register
            reg_list_bitlist = (inst_bc >> 12) % 0x10
            return 1 >> reg_list_bitlist
    def _find_reg_value(self, target_reg, start_ea, currea):
        """
        Find the constant loaded in the target register from currea
        """
        currea -= 4
        while currea >= start_ea:
            if target_reg == idc.GetOpnd(currea, 0) and \
                idc.GetMnem(currea).lower() == "mov" and \
                idc.GetOpType(currea, 1) == idaapi.o_imm:
                    return idc.GetOperandValue(currea, 1)
            currea = idc.PrevHead(currea)
        return 0

    def is_ra_saved(self, bb):
        """
        In the basic block, checks whether the semantic
        'PUSH {..., LR}' exists in any instruction, however, if 
        'POP {..., LR}' exists in the same block, ra is classified as not save
        """
        startea = bb.startEA
        endea = bb.endEA
        currea = startea
        is_ra_saved = False
        while currea < endea:
            if idc.GetMnem(currea).lower() == 'push' and \
                'lr' in idc.GetDisasm(currea).lower():
                is_ra_saved = True
            if is_ra_saved:
                if idc.GetMnem(currea).lower() == 'pop' and \
                    'lr' in idc.GetDisasm(currea).lower():
                        is_ra_saved = False
            currea = idc.NextHead(currea)
        return is_ra_saved

    def is_ra_restored(self, bb):
        """
        In the basic block, checks whether any instructions has the
        'POP {..., PC}' semantic or 
        'POP {..., LR}' and 'BX LR' semantic

        """
        startea = bb.startEA
        endea = bb.endEA
        currea = startea
        is_lr_restored = False
        is_lr_saved_in_same_block = False
        while currea < endea:
            if is_lr_restored:
                if idc.GetMnem(currea).lower() == 'bx' and \
                    'lr' in idc.GetDisasm(currea).lower():
                    return True
                if idc.GetMnem(currea).lower() == 'b':
                    # a tail jump. LR is already restored, return True
                    return True
            else:
                if idc.GetMnem(currea).lower() == 'pop' and \
                    'pc' in idc.GetDisasm(currea).lower():
                    return True 
                elif idc.GetMnem(currea).lower() == 'pop' and \
                    'lr' in idc.GetDisasm(currea).lower() and \
                    is_lr_saved_in_same_block == False:
                    is_lr_restored = True
            if idc.GetMnem(currea).lower() == 'push' and \
                'lr' in idc.GetDisasm(currea).lower():
                    is_lr_saved_in_same_block = True
            currea = idc.NextHead(currea)
        return False

    def is_sp_increased(self, bb):
        """
        Checks whether stack pointer is increased by checking for the semantic
        'ADD SP, .., <imm>'
        """
        # TODO: Make it more generic, i.e. also traces arithmetic between
        # registers
        startea = bb.startEA
        endea = bb.endEA
        currea = startea
        total_change = 0 
        reg_tracker = 0
        while currea < endea:
            if idc.GetMnem(currea).lower() == 'add' and \
                    idc.GetOperandValue(currea, 0) == SP_VALUE:
                if idc.GetOpType(currea, 2) == idaapi.o_imm:
                    total_change += idc.GetOperandValue(currea, 2)
                elif idc.GetOpType(currea, 2) == idaapi.o_reg:
                    target_reg = idc.GetOpnd(currea, 2)
                    total_change += self._find_reg_value(target_reg, startea, currea)
            elif idc.GetMnem(currea).lower() == 'pop':
                reg_list_change = self._get_num_regs_from_reg_list(currea)
                reg_tracker |= reg_list_change
            currea = idc.NextHead(currea)
        total_change += sum([int(x, 10) for x in bin(reg_tracker)[2:]]) * 4
        return total_change

    def is_sp_decreased(self, bb):
        """
        Checks whether stack pointer is decreased by checking the semantic
        'SUB SP, .., <imm>'
        if the 'PUSH' semantic exists, also need to alter the stack pointer
        by the number of registers pushed to the stack
        """
        startea = bb.startEA
        endea = bb.endEA
        currea = startea
        total_change = 0
        reg_tracker = 0
        while currea < endea:

            if idc.GetMnem(currea).lower() == 'sub' and \
                    idc.GetOperandValue(currea, 0) == SP_VALUE:
                if idc.GetOpType(currea, 2) == idaapi.o_imm:
                    total_change -= idc.GetOperandValue(currea, 2)
                elif idc.GetOpType(currea, 2) == idaapi.o_reg:
                    target_reg = idc.GetOpnd(currea, 2)
                    total_change -= self._find_reg_value(target_reg, startea, currea)
            elif idc.GetMnem(currea).lower() == 'push':
                reg_list_change = self._get_num_regs_from_reg_list(currea)
                reg_tracker |= reg_list_change
            elif idc.GetMnem(currea).lower() == 'pop':
                # if the register popped is already in the entry block, do not
                # count towards the change
                reg_list_change = self._get_num_regs_from_reg_list(currea)
                reg_tracker &= ~reg_list_change  
            currea = idc.NextHead(currea)
        total_change -= sum([int(x, 10) for x in bin(reg_tracker)[2:]]) * 4
        return total_change
 
