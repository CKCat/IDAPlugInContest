import idaapi
import idc
from ArchVerifier import ArchVerifier

SP_VALUE = 4
EDI_VALUE = 7 
ESI_VALUE = 6 
EBX_VALUE = 3
EBP_VALUE = 5

class X86Verifier(ArchVerifier):

    def __init__(self, arch):

        self.arch = arch
        self.target_regs = [EDI_VALUE, ESI_VALUE, EBX_VALUE, EBP_VALUE]
 
    def is_ra_saved(self, bb):
        """
        return address is saved automatically by call instruction in X86 
        """
        return True

    def is_ra_restored(self, bb):
        """
        Check whether the ret instruction exists in the last block
        """
        startea = bb.startEA
        endea = bb.endEA
        currea = startea
        
        while currea < endea:
            if "ret" in idc.GetMnem(currea).lower():
                return True
            currea = idc.NextHead(currea)
        return False

    def is_sp_increased(self, bb):
        """
        checks whether target registers are popped or if sp is manipulated directly
        """
        startea = bb.startEA
        endea = bb.endEA
        currea = startea
        total_change = 0 
        # regs_popped = []
        while currea < endea:
            if idc.GetMnem(currea).lower() == 'pop' and \
                    idc.GetOperandValue(currea, 0) in self.target_regs:
                    # idc.GetOperandValue(currea, 0) not in regs_popped:
                # regs_popped.append(idc.GetOperandValue(currea, 0))        
                total_change += 4
            elif idc.GetMnem(currea).lower() == 'add' and \
                idc.GetOperandValue(currea, 0) == SP_VALUE:
                total_change += idc.GetOperandValue(currea, 1)
            elif idc.GetMnem(currea).lower() == 'leave':
                # 'leave' copies ebp to esp and pushes ebp from the stack
                # automatically assumes the sp to be at the correct position
                return True
            currea = idc.NextHead(currea)
 
        return total_change

    def is_sp_decreased(self, bb):
        """
        In function prologues of x86, edi, esi, ebx and ebp are possible
        candidates to be stored on the stack. sp is usually subtracted 
        by a certain value
        """
        startea = bb.startEA
        endea = bb.endEA
        currea = startea
        total_change = 0 
        regs_pushed = []
        while currea < endea:
            if idc.GetMnem(currea).lower() == 'push' and \
                    idc.GetOperandValue(currea, 0) in self.target_regs and \
                    idc.GetOperandValue(currea, 0) not in regs_pushed:
                regs_pushed.append(idc.GetOperandValue(currea, 0))
                total_change -= 4
            elif idc.GetMnem(currea).lower() == 'sub' and \
                idc.GetOperandValue(currea, 0) == SP_VALUE:
                total_change -= idc.GetOperandValue(currea, 1)
            elif idc.GetMnem(currea).lower() == 'enter':
                # 'enter' pushes ebp onto the stack and copies esp to ebp
                total_change += 4
            currea = idc.NextHead(currea)
        return total_change
 

