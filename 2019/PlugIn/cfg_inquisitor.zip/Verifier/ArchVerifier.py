class ArchVerifier:

    def __init__(self, arch):

        self.arch = arch
   
    def is_ra_saved(self, bb):
        """
        checks whether return address is saved on the stack.
        bb: ida_gdl Basic Block object, entry basic block to be investigated
        """
        return False

    def is_ra_restored(self, bb):
        """
        checks whether return address is restored from the stack
        bb: ida_gdl Basic Block object, exit basic block to be investigated
        """
        return False

    def is_sp_decreased(self, bb):
        """
        checks whether stack pointer is decreased
        bb:ida_gdl Basic Block object, entry basic block to be investigated
        """
        return 0

    def is_sp_increased(self, bb):
        """
        checks whether stack pointer is increased
        bb:ida_gdl Basic Block object, exit basic block to be investigated
        """
        return 0
