import idaapi
import idc
from ArchVerifier import ArchVerifier

class MIPSVerifier(ArchVerifier):

    def __init__(self, arch):

        self.arch = arch
   
    def is_ra_saved(self, bb):
        """
        In the basic block, checks whether the semantic
        'sw $ra' exists in any instruction 
        """
        startea = bb.startEA
        endea = bb.endEA
        currea = startea
        while currea < endea:
            if idc.GetMnem(currea).lower() == 'sw' and \
                    'ra' in idc.GetOpnd(currea, 0).lower():
                return True
            currea = idc.NextHead(currea)
        return False

    def is_ra_restored(self, bb):
        """
        checks whether the return address is restored. and jumped back to 
        """
        # sometimes ra is restored in the basic block just before the exit 
        # block
        if idc.GetFunctionName(bb.startEA - 4) == idc.GetFunctionName(bb.startEA):
            startea = bb.startEA - 4
        else:
            startea = bb.startEA
        endea = bb.endEA
        currea = startea
        is_ra_retrieved = False
        is_ra_jumped = False
        is_tail_jumped = False
        
        while currea < endea:
            if is_ra_retrieved:
                if idc.GetMnem(currea).lower() == 'jr':
                    is_ra_jumped = True
                    break
                if idc.GetMnem(currea).lower() == 'j':
                    is_tail_jumped = True
                    break
            elif idc.GetMnem(currea).lower() == 'lw' and \
                    'ra' in idc.GetOpnd(currea, 0).lower() :
                is_ra_retrieved = True
           
            currea = idc.NextHead(currea)
        return (is_ra_retrieved and (is_ra_jumped or is_tail_jumped))


    def is_sp_increased(self, bb):
        """
        Checks whether stack pointer is increased
        """
        startea = bb.startEA
        endea = bb.endEA
        currea = startea
        total_change = 0 
        while currea < endea:
            if idc.GetMnem(currea).lower() == 'addiu' and \
                    'sp' in idc.GetOpnd(currea, 0).lower():
                opnd_val = idc.GetOperandValue(currea, 1)
                if opnd_val >> 31 == 0:
                    total_change += opnd_val
            currea = idc.NextHead(currea)
        return total_change

    def is_sp_decreased(self, bb):
        """
        Checks whether stack pointer is decreased
        """
        startea = bb.startEA
        endea = bb.endEA
        currea = startea
        total_change = 0 
        while currea < endea:
            if idc.GetMnem(currea).lower() == 'addiu' and \
                    'sp' in idc.GetOpnd(currea, 0).lower():
                opnd_val = idc.GetOperandValue(currea, 1)
                if opnd_val >> 31 == 1:
                    # two's complement
                    total_change += 0xffffffff - opnd_val + 1
                elif opnd_val < 0:
                    total_change += opnd_val
            currea = idc.NextHead(currea)
        return total_change
 

