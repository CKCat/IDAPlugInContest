from __future__ import print_function
import ida_kernwin
import idautils
import idaapi
import idc
from ida_kernwin import Choose
from Verifier import MIPSVerifier, ARMVerifier, X86Verifier

RET_BLOCK = 2
CNDRET_BLOCK = 3
NORET_BLOCK = 4
EXTNORET_BLOCK = 5

class cfg_inquisitor_plugin_t(idaapi.plugin_t):
    flags = 0
    comment = "Checks entry and exit block of CFG"
    help = "Click and see what happens!"
    wanted_name = "CFG Inquisitor"
    wanted_hotkey = ""

    def init(self):
        return idaapi.PLUGIN_KEEP

    def run(self, arg):
        c = MyChoose("CFGInquisitor")
        c.show()

    def term(self):
        pass

def PLUGIN_ENTRY():
    return cfg_inquisitor_plugin_t()

def analyze_exit_block(end_bb, verifier):
    """
    Iterate through the instructions in the basic block to see whether the following:
    1. return address is 
    """
    is_ra_restored = verifier.is_ra_restored(end_bb)
    is_sp_increased = verifier.is_sp_increased(end_bb)
    return is_ra_restored, is_sp_increased

def analyze_entry_block(start_bb, verifier):
    """
    Iterate through the first 5 instructions to see whether the following is made:
    1. stack pointer moves down
    2. registers stored in stack
    f: function start address
    """
    is_ra_saved = verifier.is_ra_saved(start_bb)
    is_sp_decreased = verifier.is_sp_decreased(start_bb)    
    return is_ra_saved, is_sp_decreased

################################
#
# Class for frontend
#
###############################
class MyChoose(Choose):

    def __init__(self, title, flags = 0, modal = False):
        Choose.__init__(
            self,
            title,
            [ ["Address", 10], ["Name", 30] , ["Valid Entry Block", 10], ["Valid Exit Block", 10], \
                    ["is_ra_saved", 10], ["is_ra_restored",10], ["sp_decreased_by", 10], \
                    ["sp_increased_by", 10]],
            flags = flags | Choose.CH_RESTORE | Choose.CH_CAN_REFRESH)
        self.n = 0
        self.arch_verifier = None

        arch = idaapi.get_inf_structure().procName.lower()
        if "mips" in arch:
            self.arch_verifier = MIPSVerifier.MIPSVerifier(arch)
        elif "arm" in arch:
            self.show_unfinished_warning("arm")
            self.arch_verifier = ARMVerifier.ARMVerifier(arch)
        elif "metapc" in arch:
            self.show_unfinished_warning("metapc")
            self.arch_verifier = X86Verifier.X86Verifier(arch)
        else:
            raise RuntimeError("Verifier not implemented yet. Please contact developers for details")
 
        self.items = [ self.make_item(f) for f in idautils.Functions() ]
        self.selcount = 0
        self.modal = modal

    def show_unfinished_warning(self, arch):
        """
        Some architectures are still work in progress. If the user decides to use it they should
        do it at their own risk
        """
        idaapi.warning("The architecture {} is still work in progress. Please use at your own risk".format(arch))

    def OnInit(self):
        return True

    def OnGetSize(self):
        n = len(self.items)
        return n

    def OnGetLine(self, n):
        return self.items[n]

    def OnRefresh(self, n):
        return None # call standard refresh

    def OnSelectLine(self, n):
        self.selcount += 1
        idc.Jump(int(self.items[n][0], 16))
        return (Choose.NOTHING_CHANGED, )

    def show(self):
        return self.Show(self.modal) >= 0

    def make_item(self, f):
        func = idaapi.get_func(f)
        fc = idaapi.FlowChart(func)
        start_bb = fc[0]
        end_bb = fc[len(list(fc))-1]
        
        is_ra_saved, is_sp_decreased = analyze_entry_block(start_bb, self.arch_verifier)
        is_ra_restored, is_sp_increased = analyze_exit_block(
                end_bb, 
                self.arch_verifier)
        is_valid_entry = True
        is_valid_exit = True
        # If $ra is stored, $ra has to be retrieved, and vice versa
        # if $ra is saved, and $ra is not retreived, the exit block is invalid
        # if $ra is retrieved and $ra is not stored at the begining, the entry block is invalid
        if is_ra_saved != is_ra_restored:
            if is_ra_saved:
                is_valid_exit = False
            else:
                is_valid_entry = False
        
        if type(is_sp_increased) == bool:
            is_sp_increased = is_sp_decreased * -1
            is_valid_exit = True
        elif type(is_sp_increased) == int:
            if is_sp_decreased + is_sp_increased != 0:
                if is_sp_decreased == 0:
                    is_valid_entry = False
                else:
                    is_valid_exit = False

        if not is_valid_exit and len(list(fc)) != 1:
            # check again to see whether there are other valid exit points
            for candidate_bb in fc:
                if candidate_bb.type == RET_BLOCK or \
                    candidate_bb.type == CNDRET_BLOCK or \
                    candidate_bb.type == NORET_BLOCK or \
                    candidate_bb.type == EXTNORET_BLOCK:
                    c_is_ra_restored, c_is_sp_increased = analyze_exit_block(
                        candidate_bb, 
                        self.arch_verifier)
                    if type(is_sp_increased) == bool:
                        is_sp_increased = is_sp_decreased * -1
                        is_ra_restored = c_is_ra_restored
                        is_valid_exit = True
                        break
                    else:
                        if is_ra_saved == is_ra_restored and \
                            is_sp_decreased + is_sp_increased == 0:
                            is_valid_exit = True
                            is_ra_restored = c_is_ra_restored
                            is_sp_increased = c_is_sp_increased
                            break

        r = ["{:08X}".format(f), idc.GetFunctionName(f), str(is_valid_entry), str(is_valid_exit), str(is_ra_saved), str(is_ra_restored), str(is_sp_decreased), str(is_sp_increased)]
        self.n += 1
        return r

