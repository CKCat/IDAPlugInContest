#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# deREferencing - by @danigargu
#

arrow_symbol      = "->"
show_leyend       = True
min_string_len    = 3
max_string_len    = 50
max_deref_levels  = 2
deref_limit       = 20
show_area_name    = True
highlight_changes = True
highlight_color   = 0xFFD073
n_stack_entries   = 150


