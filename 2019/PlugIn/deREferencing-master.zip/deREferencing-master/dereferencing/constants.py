#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# deREferencing - by @danigargu
#

PLUGIN_NAME = 'deREferencing'
REGS_WIDGET_TITLE  = "%s - Registers" % PLUGIN_NAME
STACK_WIDGET_TITLE = "%s - Stack" % PLUGIN_NAME
DBG_MENU_PATH = "Debugger/Debugger windows/"