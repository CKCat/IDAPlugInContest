toolbag
=======

The IDA Toolbag is a plugin providing supplemental functionality to Hex-Rays IDA Pro disassembler.