DOCUMENTATION
-------------
Documentation and examples at http://thunkers.net/~deft/code/toolbag

https://github.com/aaronportnoy/toolbag/


THX
----
bluepantz, navs, salc, wtfuzz

Those in the private channels on busticati.org

Our Kind friends with adderalL prescriptions

Readers of our MindshaRE blog posts (https://www.google.com/search?q=site:dvlabs.tippingpoint.com%20mindshare)

The NYC crew

visi from kenshoto

beta testers!