
# Import all local structure modules
import elf
import pe
import win32

