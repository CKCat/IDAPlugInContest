This code is 'vdb' from visi @ kenshoto: http://visi.kenshoto.com/

